module.exports={
    cookieSecret:'myblog',//用户cookie加密与数据库无关
    db:'blog',
    host:'localhost',
    port:27017
};
